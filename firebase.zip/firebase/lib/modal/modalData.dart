class ModelData{
  String? id,name,mobile,std,key;
  ModelData({this.id,this.name,this.mobile,this.std,this.key});
}